# Campaign artwork

Three A2 poster PDFs and PNG previews, four feed cards, two story cards, four hoarding studies and two photo placement mockups. Poster QRs now point to the public GitHub demo. Picasso/Turing filenames follow the actual image identities.

The four illustrations are GPT concept art. These assets are campaign proposals, not Adobe Firefly outputs. Campus installations, dimensions and rewards remain proposed. Swarm Night is planned for day 14.
