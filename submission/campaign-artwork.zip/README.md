# Campaign artwork

The three A3 print posters retain the earlier approved copy, with updated layouts. The pack also contains the existing feed, story, hoarding and placement files. All four campaign illustrations are GPT concept art. The model and posters are campaign prototypes. Adobe perks remain tentative.
