# Final posters - revision 2

Three A3 portrait print PDFs with matching PNG previews. The previous approved campaign copy is retained. Layout, print size, image space and QR placement are refined. Each has one QR code to the public demo. Artwork uses the existing GPT concept illustrations, not new Firefly generations. Earlier poster versions are retained in ../iterations/posters-v1/.
